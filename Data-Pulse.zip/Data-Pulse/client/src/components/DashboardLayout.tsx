import { Sidebar, MobileHeader } from "./Sidebar";
import { useStore } from "@/hooks/use-store";
import { Moon, Sun, Download } from "lucide-react";
import { cn } from "@/lib/utils";
// @ts-ignore
import html2pdf from "html2pdf.js";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

export function DashboardLayout({ children, title, subtitle }: DashboardLayoutProps) {
  const { isSidebarCollapsed, theme, toggleTheme } = useStore();

  const handleExportPDF = () => {
    const element = document.getElementById("dashboard-content");
    const opt = {
      margin: 10,
      filename: `dashboard-${title.toLowerCase()}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };
    html2pdf().set(opt).from(element).save();
  };

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      <Sidebar />
      <MobileHeader />
      
      <main 
        className={cn(
          "transition-all duration-300 ease-in-out min-h-screen",
          isSidebarCollapsed ? "md:pl-[80px]" : "md:pl-[260px]"
        )}
      >
        <div className="max-w-[1600px] mx-auto p-4 md:p-8 space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-display font-bold tracking-tight text-foreground">{title}</h1>
              {subtitle && <p className="mt-1 text-muted-foreground text-sm">{subtitle}</p>}
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center px-3 py-1.5 bg-secondary/50 rounded-full text-xs font-medium text-muted-foreground border border-border/50">
                <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
                Live 2025 Data
              </div>

              <button
                onClick={toggleTheme}
                className="p-2.5 rounded-full bg-card hover:bg-secondary border border-border/50 text-foreground transition-all shadow-sm hover:shadow-md"
              >
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </button>

              <button
                onClick={handleExportPDF}
                className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-primary text-primary-foreground font-medium text-sm shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-200"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </button>
            </div>
          </div>

          {/* Content */}
          <div id="dashboard-content" className="bg-background">
            {children}
          </div>
          
          {/* Footer */}
          <footer className="border-t border-border/40 pt-8 mt-12">
            <div className="flex flex-col md:flex-row justify-between items-center text-xs text-muted-foreground">
              <p>© 2025 GlobalInsight Analytics. Enterprise License.</p>
              <div className="flex gap-4 mt-2 md:mt-0">
                <span>Terms</span>
                <span>Privacy</span>
                <span>Status</span>
              </div>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}
