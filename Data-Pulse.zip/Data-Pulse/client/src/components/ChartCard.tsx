import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface ChartCardProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  action?: ReactNode;
}

export function ChartCard({ title, subtitle, children, className, action }: ChartCardProps) {
  return (
    <div className={cn(
      "bg-card border border-border rounded-2xl shadow-sm hover:shadow-md transition-shadow duration-300 flex flex-col overflow-hidden",
      className
    )}>
      <div className="p-6 border-b border-border/40 flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-foreground font-display tracking-tight">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
        </div>
        {action && <div>{action}</div>}
      </div>
      <div className="flex-1 p-4 relative min-h-[300px]">
        {children}
        {/* Subtle watermark or year label */}
        <div className="absolute bottom-4 right-6 text-[10px] font-mono text-muted-foreground/30 pointer-events-none">
          EST. 2025
        </div>
      </div>
    </div>
  );
}
