import { Link, useLocation } from "wouter";
import { useStore } from "@/hooks/use-store";
import { 
  LayoutDashboard, 
  BarChart2, 
  Globe2, 
  ChevronLeft, 
  Menu,
  PieChart
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const items = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/performance", label: "Performance", icon: BarChart2 },
  { href: "/geography", label: "Geography", icon: Globe2 },
];

export function Sidebar() {
  const [location] = useLocation();
  const { isSidebarCollapsed, toggleSidebar } = useStore();

  return (
    <motion.aside
      initial={false}
      animate={{ width: isSidebarCollapsed ? "80px" : "260px" }}
      className="fixed left-0 top-0 h-screen bg-card border-r border-border z-30 shadow-xl hidden md:flex flex-col"
    >
      <div className="h-16 flex items-center justify-between px-6 border-b border-border/50">
        {!isSidebarCollapsed && (
          <div className="flex items-center gap-2 text-primary font-bold text-xl tracking-tight">
            <PieChart className="w-6 h-6" />
            <span>GlobalInsight</span>
          </div>
        )}
        {isSidebarCollapsed && (
          <div className="w-full flex justify-center">
            <PieChart className="w-6 h-6 text-primary" />
          </div>
        )}
        <button 
          onClick={toggleSidebar}
          className={cn(
            "p-1.5 rounded-lg hover:bg-muted text-muted-foreground transition-colors",
            isSidebarCollapsed && "hidden"
          )}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1">
        {items.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.href} href={item.href}>
              <div 
                className={cn(
                  "flex items-center px-3 py-3 rounded-xl cursor-pointer transition-all duration-200 group relative overflow-hidden",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/20 font-medium" 
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  isSidebarCollapsed && "justify-center"
                )}
              >
                <Icon className={cn("w-5 h-5 flex-shrink-0", !isSidebarCollapsed && "mr-3")} />
                {!isSidebarCollapsed && (
                  <span className="truncate">{item.label}</span>
                )}
                
                {/* Tooltip for collapsed state */}
                {isSidebarCollapsed && (
                  <div className="absolute left-full ml-4 px-2 py-1 bg-popover text-popover-foreground text-sm rounded shadow-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                    {item.label}
                  </div>
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {!isSidebarCollapsed && (
        <div className="p-6 border-t border-border/50">
          <div className="bg-secondary/50 rounded-xl p-4">
            <h4 className="text-sm font-semibold mb-1">2025 Projection</h4>
            <p className="text-xs text-muted-foreground">Data based on latest World Bank estimates.</p>
          </div>
        </div>
      )}
    </motion.aside>
  );
}

export function MobileHeader() {
  const [isOpen, setIsOpen] = React.useState(false);
  const [location] = useLocation();

  return (
    <div className="md:hidden sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border px-4 h-14 flex items-center justify-between">
      <div className="flex items-center gap-2 font-bold text-lg text-primary">
        <PieChart className="w-5 h-5" />
        <span>GlobalInsight</span>
      </div>
      <button onClick={() => setIsOpen(!isOpen)} className="p-2 -mr-2 text-muted-foreground">
        <Menu className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="absolute top-14 left-0 w-full bg-background border-b border-border shadow-lg p-4 flex flex-col gap-2">
          {items.map((item) => (
            <Link key={item.href} href={item.href}>
              <div 
                className={cn(
                  "px-4 py-3 rounded-lg text-sm font-medium",
                  location === item.href ? "bg-primary text-primary-foreground" : "bg-secondary/50 text-foreground"
                )}
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

import React from "react";
