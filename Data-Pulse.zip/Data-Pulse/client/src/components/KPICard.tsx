import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight, Minus, TrendingUp } from "lucide-react";
import * as LucideIcons from "lucide-react";
import { useStore } from "@/hooks/use-store";

interface KPICardProps {
  label: string;
  value: string | number;
  change?: string;
  trend?: "up" | "down" | "neutral";
  icon?: string;
}

export function KPICard({ label, value, change, trend, icon }: KPICardProps) {
  // Dynamic icon rendering
  const IconComponent = icon ? (LucideIcons[icon as keyof typeof LucideIcons] as any) : TrendingUp;

  return (
    <div className="group relative overflow-hidden rounded-2xl bg-card border border-border shadow-sm hover:shadow-xl hover:border-border/80 transition-all duration-300 p-6">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="relative flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{label}</p>
          <h3 className="text-3xl font-display font-bold text-foreground tracking-tight">{value}</h3>
        </div>
        <div className="p-3 bg-secondary/50 rounded-xl text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
          {IconComponent && <IconComponent className="w-5 h-5" />}
        </div>
      </div>

      {change && (
        <div className="relative mt-4 flex items-center gap-2">
          <div className={cn(
            "flex items-center text-xs font-semibold px-2 py-0.5 rounded-full",
            trend === 'up' && "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
            trend === 'down' && "bg-rose-500/10 text-rose-600 dark:text-rose-400",
            trend === 'neutral' && "bg-slate-500/10 text-slate-600 dark:text-slate-400",
          )}>
            {trend === 'up' && <ArrowUpRight className="w-3 h-3 mr-1" />}
            {trend === 'down' && <ArrowDownRight className="w-3 h-3 mr-1" />}
            {trend === 'neutral' && <Minus className="w-3 h-3 mr-1" />}
            {change}
          </div>
          <span className="text-xs text-muted-foreground">vs last year</span>
        </div>
      )}
    </div>
  );
}
