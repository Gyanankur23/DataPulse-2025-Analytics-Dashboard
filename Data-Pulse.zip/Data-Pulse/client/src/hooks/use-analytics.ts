import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useOverviewData() {
  return useQuery({
    queryKey: [api.analytics.overview.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.overview.path);
      if (!res.ok) throw new Error("Failed to fetch overview data");
      return api.analytics.overview.responses[200].parse(await res.json());
    },
  });
}

export function usePerformanceData() {
  return useQuery({
    queryKey: [api.analytics.performance.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.performance.path);
      if (!res.ok) throw new Error("Failed to fetch performance data");
      return api.analytics.performance.responses[200].parse(await res.json());
    },
  });
}

export function useGeographyData() {
  return useQuery({
    queryKey: [api.analytics.geography.path],
    queryFn: async () => {
      const res = await fetch(api.analytics.geography.path);
      if (!res.ok) throw new Error("Failed to fetch geography data");
      return api.analytics.geography.responses[200].parse(await res.json());
    },
  });
}
