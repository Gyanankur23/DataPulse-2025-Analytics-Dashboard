import { create } from 'zustand';

interface AppState {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  selectedCountry: string | null;
  setSelectedCountry: (country: string | null) => void;
  yearFilter: number;
  setYearFilter: (year: number) => void;
  isSidebarCollapsed: boolean;
  toggleSidebar: () => void;
}

export const useStore = create<AppState>((set) => ({
  theme: 'light',
  toggleTheme: () => set((state) => {
    const newTheme = state.theme === 'light' ? 'dark' : 'light';
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    return { theme: newTheme };
  }),
  selectedCountry: null,
  setSelectedCountry: (country) => set({ selectedCountry: country }),
  yearFilter: 2025,
  setYearFilter: (year) => set({ yearFilter: year }),
  isSidebarCollapsed: false,
  toggleSidebar: () => set((state) => ({ isSidebarCollapsed: !state.isSidebarCollapsed })),
}));
