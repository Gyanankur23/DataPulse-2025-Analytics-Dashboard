import { DashboardLayout } from "@/components/DashboardLayout";
import { ChartCard } from "@/components/ChartCard";
import { useGeographyData } from "@/hooks/use-analytics";
import { useStore } from "@/hooks/use-store";
import ReactECharts from "echarts-for-react";
import * as echarts from 'echarts';
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect, useState } from "react";
// @ts-ignore
import worldMap from "@/assets/world.json"; 

// NOTE: Since I cannot guarantee a local world.json file exists in this generation context, 
// I will simulate the map registration. In a real project, ensure world.json is in public/assets or imported.
// For this demo, I will register a simple map or handle the fallback gracefully if data missing.

export default function Geography() {
  const { data, isLoading } = useGeographyData();
  const { theme, selectedCountry, setSelectedCountry } = useStore();
  const [mapLoaded, setMapLoaded] = useState(false);

  const isDark = theme === 'dark';
  const textColor = isDark ? '#e2e8f0' : '#1e293b';

  // Load map data
  useEffect(() => {
    // In a real app, you'd fetch this from a CDN or local file
    fetch('https://raw.githubusercontent.com/apache/echarts-examples/master/public/data/asset/geo/world.json')
      .then(response => response.json())
      .then(geoJson => {
        echarts.registerMap('world', geoJson);
        setMapLoaded(true);
      })
      .catch(err => console.error("Map load failed", err));
  }, []);

  const mapOption = (data && mapLoaded) ? {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c}M',
      backgroundColor: isDark ? '#1e293b' : '#fff',
      textStyle: { color: textColor }
    },
    visualMap: {
      min: 0,
      max: 1500,
      text: ['High', 'Low'],
      realtime: false,
      calculable: true,
      inRange: {
        color: ['#e0f2fe', '#0ea5e9', '#0369a1']
      },
      textStyle: { color: textColor }
    },
    series: [
      {
        name: 'World Population (2025)',
        type: 'map',
        map: 'world',
        roam: true,
        emphasis: {
          label: { show: true },
          itemStyle: { areaColor: '#facc15' }
        },
        select: {
          itemStyle: { areaColor: '#facc15' }
        },
        data: data.worldData
      }
    ]
  } : null;

  const handleChartClick = (params: any) => {
    if (params.componentType === 'series') {
      setSelectedCountry(params.name);
    }
  };

  const selectedData = data?.worldData.find(c => c.name === selectedCountry);

  return (
    <DashboardLayout title="Geographic Distribution" subtitle="Global Population Heatmap 2025">
      <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-200px)] min-h-[600px]">
        
        {/* Map Container */}
        <ChartCard title="World Map" className="flex-1">
          {isLoading || !mapLoaded ? (
            <div className="flex items-center justify-center h-full">
              <Skeleton className="w-full h-full rounded-xl" />
              <div className="absolute text-muted-foreground">Loading Map Data...</div>
            </div>
          ) : (
            <ReactECharts 
              option={mapOption} 
              style={{ height: '100%', minHeight: '500px' }} 
              theme={isDark ? 'dark' : undefined}
              onEvents={{ click: handleChartClick }}
            />
          )}
        </ChartCard>

        {/* Sidebar Details */}
        <div className="w-full lg:w-80 flex flex-col gap-6">
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm h-full flex flex-col">
            <h3 className="text-lg font-display font-bold mb-4">Country Details</h3>
            
            {selectedCountry ? (
              <div className="space-y-6 animate-in slide-in-from-right duration-300">
                <div>
                  <h2 className="text-3xl font-bold text-primary">{selectedCountry}</h2>
                  <p className="text-sm text-muted-foreground">Selected Region</p>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-secondary/50 rounded-xl">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Population (2025)</p>
                    <p className="text-2xl font-mono font-semibold">{selectedData?.value.toLocaleString()}M</p>
                  </div>

                  <div className="p-4 bg-secondary/50 rounded-xl">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Growth Status</p>
                    <p className="text-lg font-medium text-emerald-600 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      Stable Growth
                    </p>
                  </div>
                  
                  {selectedData?.details && (
                    <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-100 dark:border-blue-900">
                      <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
                        {selectedData.details}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground p-4 border-2 border-dashed border-border rounded-xl">
                <p>Select a country on the map to view detailed 2025 analytics.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
