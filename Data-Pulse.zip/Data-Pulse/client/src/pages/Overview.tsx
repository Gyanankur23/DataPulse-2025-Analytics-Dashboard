import { DashboardLayout } from "@/components/DashboardLayout";
import { KPICard } from "@/components/KPICard";
import { ChartCard } from "@/components/ChartCard";
import { useOverviewData } from "@/hooks/use-analytics";
import { useStore } from "@/hooks/use-store";
import ReactECharts from "echarts-for-react";
import { Loader2, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Overview() {
  const { data, isLoading, error } = useOverviewData();
  const { theme } = useStore();

  const isDark = theme === 'dark';
  const textColor = isDark ? '#e2e8f0' : '#1e293b';
  const gridColor = isDark ? '#334155' : '#e2e8f0';

  // Chart Configs
  const globalTrendOption = data ? {
    tooltip: {
      trigger: 'axis',
      backgroundColor: isDark ? '#1e293b' : '#fff',
      borderColor: gridColor,
      textStyle: { color: textColor }
    },
    legend: {
      data: ['Population (Billions)', 'GDP (Trillions)'],
      textStyle: { color: textColor },
      bottom: 0
    },
    grid: { top: 40, right: 40, bottom: 60, left: 50, containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.globalTrend.map(d => d.year),
      axisLine: { lineStyle: { color: gridColor } },
      axisLabel: { color: isDark ? '#94a3b8' : '#64748b' }
    },
    yAxis: [
      {
        type: 'value',
        name: 'Population',
        position: 'left',
        splitLine: { lineStyle: { color: gridColor, type: 'dashed' } },
        axisLabel: { color: isDark ? '#94a3b8' : '#64748b' }
      },
      {
        type: 'value',
        name: 'GDP',
        position: 'right',
        splitLine: { show: false },
        axisLabel: { color: isDark ? '#94a3b8' : '#64748b', formatter: '${value}T' }
      }
    ],
    series: [
      {
        name: 'Population (Billions)',
        type: 'line',
        smooth: true,
        showSymbol: false,
        areaStyle: {
          opacity: 0.2,
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [{ offset: 0, color: '#3b82f6' }, { offset: 1, color: 'rgba(59,130,246,0)' }]
          }
        },
        itemStyle: { color: '#3b82f6' },
        data: data.globalTrend.map(d => d.population)
      },
      {
        name: 'GDP (Trillions)',
        type: 'line',
        yAxisIndex: 1,
        smooth: true,
        showSymbol: false,
        itemStyle: { color: '#10b981' },
        lineStyle: { width: 3 },
        data: data.globalTrend.map(d => d.gdp)
      }
    ]
  } : {};

  const demographicsOption = data ? {
    tooltip: {
      trigger: 'item',
      backgroundColor: isDark ? '#1e293b' : '#fff',
      textStyle: { color: textColor }
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      textStyle: { color: textColor }
    },
    series: [
      {
        name: 'Population by Region',
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['40%', '50%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: isDark ? '#0f172a' : '#fff',
          borderWidth: 2
        },
        label: { show: false, position: 'center' },
        emphasis: {
          label: {
            show: true,
            fontSize: 20,
            fontWeight: 'bold',
            color: textColor
          }
        },
        labelLine: { show: false },
        data: data.demographics
      }
    ]
  } : {};

  if (error) {
    return (
      <div className="flex h-screen items-center justify-center text-destructive bg-destructive/5 rounded-xl border border-destructive/20 m-8">
        <div className="flex flex-col items-center gap-4">
          <AlertCircle className="w-12 h-12" />
          <p className="font-semibold text-lg">Failed to load analytics data.</p>
          <button onClick={() => window.location.reload()} className="px-4 py-2 bg-destructive text-white rounded-lg text-sm">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <DashboardLayout title="Overview" subtitle="Global 2025 Economic & Demographic Summary">
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-pulse">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-2xl w-full" />)}
          <Skeleton className="col-span-1 lg:col-span-3 h-[400px] rounded-2xl" />
          <Skeleton className="col-span-1 lg:col-span-1 h-[400px] rounded-2xl" />
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in duration-500">
          {/* KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {data?.kpis.map((kpi, idx) => (
              <KPICard key={idx} {...kpi} />
            ))}
          </div>

          {/* Charts Row 1 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <ChartCard title="Global Trajectory" subtitle="Population vs. GDP Growth (2020-2030)" className="lg:col-span-2">
              <ReactECharts option={globalTrendOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
            </ChartCard>
            
            <ChartCard title="Regional Distribution" subtitle="2025 Population Share">
              <ReactECharts option={demographicsOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
            </ChartCard>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
