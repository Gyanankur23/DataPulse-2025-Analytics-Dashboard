import { DashboardLayout } from "@/components/DashboardLayout";
import { ChartCard } from "@/components/ChartCard";
import { usePerformanceData } from "@/hooks/use-analytics";
import { useStore } from "@/hooks/use-store";
import ReactECharts from "echarts-for-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Performance() {
  const { data, isLoading } = usePerformanceData();
  const { theme } = useStore();
  
  const isDark = theme === 'dark';
  const textColor = isDark ? '#e2e8f0' : '#1e293b';
  const gridColor = isDark ? '#334155' : '#e2e8f0';

  // --- Chart Configurations ---
  const barOption = data ? {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: isDark ? '#1e293b' : '#fff',
      textStyle: { color: textColor }
    },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: {
      type: 'value',
      boundaryGap: [0, 0.01],
      splitLine: { lineStyle: { color: gridColor } },
      axisLabel: { color: isDark ? '#94a3b8' : '#64748b' }
    },
    yAxis: {
      type: 'category',
      data: data.topCountries.map(d => d.name),
      axisLabel: { color: isDark ? '#94a3b8' : '#64748b' }
    },
    series: [
      {
        name: 'Population (Millions)',
        type: 'bar',
        data: data.topCountries.map(d => d.value),
        itemStyle: {
          borderRadius: [0, 4, 4, 0],
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 1, y2: 0,
            colorStops: [{ offset: 0, color: '#6366f1' }, { offset: 1, color: '#8b5cf6' }]
          }
        },
      }
    ]
  } : {};

  const growthOption = data ? {
    tooltip: {
      trigger: 'item',
      backgroundColor: isDark ? '#1e293b' : '#fff',
      textStyle: { color: textColor }
    },
    xAxis: {
      type: 'category',
      data: data.regionalGrowth.map(d => d.name),
      axisLabel: { color: isDark ? '#94a3b8' : '#64748b', interval: 0, rotate: 30 }
    },
    yAxis: {
      type: 'value',
      name: 'GDP Growth %',
      splitLine: { lineStyle: { color: gridColor, type: 'dashed' } },
      axisLabel: { color: isDark ? '#94a3b8' : '#64748b' }
    },
    series: [
      {
        data: data.regionalGrowth.map(d => ({
          value: d.value,
          itemStyle: { color: d.value > 3 ? '#10b981' : '#f59e0b' }
        })),
        type: 'bar',
        itemStyle: { borderRadius: [4, 4, 0, 0] },
        barWidth: '50%',
      }
    ]
  } : {};

  const radarOption = data ? {
    tooltip: {},
    radar: {
      indicator: data.deviceDistribution.map(d => ({ name: d.name, max: 100 })),
      axisName: { color: isDark ? '#94a3b8' : '#64748b' },
      splitArea: { areaStyle: { color: isDark ? ['#1e293b', '#0f172a'] : ['#f8fafc', '#fff'] } },
      splitLine: { lineStyle: { color: gridColor } }
    },
    series: [
      {
        name: 'Device Usage (%)',
        type: 'radar',
        areaStyle: { color: 'rgba(59, 130, 246, 0.2)' },
        lineStyle: { color: '#3b82f6', width: 2 },
        itemStyle: { color: '#3b82f6' },
        data: [
          {
            value: data.deviceDistribution.map(d => d.value),
            name: 'Device Usage (%)'
          }
        ]
      }
    ]
  } : {};

  const bubbleOption = data ? {
    tooltip: {
      formatter: '{b}: {c}% Usage',
      backgroundColor: isDark ? '#1e293b' : '#fff',
      textStyle: { color: textColor }
    },
    grid: { containLabel: true, bottom: 20 },
    xAxis: { name: 'Region', show: false },
    yAxis: { name: 'Usage', show: false },
    series: data.internetUsage.map((item, idx) => ({
      name: item.name,
      data: [[idx * 10, item.value, item.value * 2]], // x, y, size
      type: 'scatter',
      symbolSize: function (data: any) {
        return Math.sqrt(data[2]) * 5;
      },
      itemStyle: {
        shadowBlur: 10,
        shadowColor: 'rgba(0,0,0,0.2)',
        color: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][idx % 5]
      }
    }))
  } : {};

  return (
    <DashboardLayout title="Performance Metrics" subtitle="Deep Dive into Regional Growth & Digital Adoption">
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-pulse">
          <Skeleton className="h-[400px] rounded-2xl" />
          <Skeleton className="h-[400px] rounded-2xl" />
          <Skeleton className="h-[400px] rounded-2xl" />
          <Skeleton className="h-[400px] rounded-2xl" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-500">
          <ChartCard title="Top 10 Populous Nations" subtitle="2025 Estimates (Millions)">
            <ReactECharts option={barOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
          </ChartCard>

          <ChartCard title="GDP Growth by Region" subtitle="Annual Percentage Rate">
            <ReactECharts option={growthOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
          </ChartCard>

          <ChartCard title="Digital Device Access" subtitle="Penetration Rate (%)">
            <ReactECharts option={radarOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
          </ChartCard>

          <ChartCard title="Internet Usage Volume" subtitle="Bubble Size by Active Users">
            <ReactECharts option={bubbleOption} style={{ height: '400px' }} theme={isDark ? 'dark' : undefined} />
          </ChartCard>
        </div>
      )}
    </DashboardLayout>
  );
}
