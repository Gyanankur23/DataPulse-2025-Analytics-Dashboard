## Packages
echarts | Core charting library
echarts-for-react | React wrapper for ECharts
html2pdf.js | For exporting dashboard to PDF
zustand | Global state management for filters and theme
lucide-react | Icon library (already in stack but confirming usage)
framer-motion | For smooth sidebar and layout animations

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Lexend", "sans-serif"],
}
ECharts requires careful resizing handling in flex/grid layouts.
PDF export needs to handle canvas elements correctly (html2pdf generally handles this but might need specific options).
