import { z } from 'zod';
import { overviewResponseSchema, performanceResponseSchema, geographyResponseSchema } from './schema';

export const api = {
  analytics: {
    overview: {
      method: 'GET' as const,
      path: '/api/analytics/overview',
      responses: {
        200: overviewResponseSchema,
      },
    },
    performance: {
      method: 'GET' as const,
      path: '/api/analytics/performance',
      responses: {
        200: performanceResponseSchema,
      },
    },
    geography: {
      method: 'GET' as const,
      path: '/api/analytics/geography',
      responses: {
        200: geographyResponseSchema,
      },
    },
  },
};
