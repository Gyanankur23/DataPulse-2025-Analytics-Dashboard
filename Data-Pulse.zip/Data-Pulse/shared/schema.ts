import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const kpiSchema = z.object({
  label: z.string(),
  value: z.union([z.string(), z.number()]),
  change: z.string().optional(),
  trend: z.enum(["up", "down", "neutral"]).optional(),
  icon: z.string().optional(), // lucide icon name
});

export const chartDataSchema = z.object({
  name: z.string(),
  value: z.number(),
  category: z.string().optional(),
  color: z.string().optional(),
});

export const overviewResponseSchema = z.object({
  kpis: z.array(kpiSchema),
  globalTrend: z.array(z.object({
    year: z.string(),
    population: z.number(),
    gdp: z.number(),
  })),
  demographics: z.array(chartDataSchema),
});

export const performanceResponseSchema = z.object({
  topCountries: z.array(chartDataSchema),
  regionalGrowth: z.array(chartDataSchema),
  internetUsage: z.array(chartDataSchema),
  deviceDistribution: z.array(chartDataSchema),
});

export const geographyResponseSchema = z.object({
  worldData: z.array(z.object({
    id: z.string(),
    name: z.string(),
    value: z.number(),
    details: z.string().optional(),
  })),
});

export type KPI = z.infer<typeof kpiSchema>;
export type ChartData = z.infer<typeof chartDataSchema>;
