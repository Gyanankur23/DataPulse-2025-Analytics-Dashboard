import { overviewResponseSchema, performanceResponseSchema, geographyResponseSchema } from "@shared/schema";
import { z } from "zod";
import fs from "fs/promises";
import path from "path";

export interface IStorage {
  getOverviewData(): Promise<z.infer<typeof overviewResponseSchema>>;
  getPerformanceData(): Promise<z.infer<typeof performanceResponseSchema>>;
  getGeographyData(): Promise<z.infer<typeof geographyResponseSchema>>;
}

export class FileStorage implements IStorage {
  private async readJson<T>(filename: string): Promise<T> {
    const filePath = path.join(process.cwd(), "server", "data", filename);
    const content = await fs.readFile(filePath, "utf-8");
    return JSON.parse(content);
  }

  async getOverviewData() {
    return this.readJson<z.infer<typeof overviewResponseSchema>>("overview.json");
  }

  async getPerformanceData() {
    return this.readJson<z.infer<typeof performanceResponseSchema>>("performance.json");
  }

  async getGeographyData() {
    return this.readJson<z.infer<typeof geographyResponseSchema>>("geography.json");
  }
}

export const storage = new FileStorage();
